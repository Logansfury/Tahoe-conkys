#!/bin/sh

cd "$(dirname "$0")"

sleep 1
conky -c gauges &

sleep 1
conky -c 1/conkyrc1 &

sleep 1
conky -c 2/conkyrc2 &

sleep 1
conky -c 3/conkyrc3 &

sleep 1
conky -c 4/conkyrc4 &

exit