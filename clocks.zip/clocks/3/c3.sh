#!/bin/sh

cd "$(dirname "$0")"

sleep 2
conky -c c3 &

exit