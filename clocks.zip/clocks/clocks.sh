#!/bin/sh

cd "/home/logansfury/.conky/Tahoe/clocks"
sleep 0.2
conky -c conkyrc &

sleep 0.2
cd "/home/logansfury/.conky/Tahoe/clocks/1"
conky -c c1 &

sleep 0.2
cd "/home/logansfury/.conky/Tahoe/clocks/2"
conky -c c2 &

sleep 0.2
cd "/home/logansfury/.conky/Tahoe/clocks/3"
conky -c c3 &

sleep 0.2
cd "/home/logansfury/.conky/Tahoe/clocks/4"
conky -c c4 &

exit
