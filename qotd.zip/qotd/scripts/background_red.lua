-- background.lua
-- by @wim66
-- Feb 16, 2026 (fixed, safe for Conky)

require 'cairo'
local status, cairo_xlib = pcall(require, 'cairo_xlib')
if not status then
    cairo_xlib = setmetatable({}, {__index = function(_, key) return _G[key] end})
end

-- Load settings.lua
local script_path = debug.getinfo(1, 'S').source:match[[^@?(.*[\/])[^\/]-$]]
local parent_path = script_path:match("^(.*[\\/])resources[\\/].*$") or ""
package.path = package.path .. ";" .. parent_path .. "?.lua"

local status, err = pcall(function() require("settings") end)
if not status then print("Error loading settings.lua: " .. err); return end
if not conky_vars then print("conky_vars function is not defined in settings.lua"); return end
conky_vars()

-- Helpers
local unpack = table.unpack or unpack

local function parse_border_color(str)
    local gradient = {}
    for pos, col, alpha in str:gmatch("([%d%.]+),0x(%x+),([%d%.]+)") do
        table.insert(gradient, {tonumber(pos), tonumber(col,16), tonumber(alpha)})
    end
    if #gradient == 3 then return gradient end
    return { {0,0x990000,1}, {0.5,0xff0000,1}, {1,0x990000,1} }
end

local function parse_bg_color(str)
    local hex, alpha = str:match("0x(%x+),([%d%.]+)")
    if hex and alpha then return { {1, tonumber(hex,16), tonumber(alpha)} } end
    return { {1,0x550000,0.8} }
end

local function parse_layer2_color(str)
    local gradient = {}
    for pos, col, alpha in str:gmatch("([%d%.]+),0x(%x+),([%d%.]+)") do
        table.insert(gradient, {tonumber(pos), tonumber(col,16), tonumber(alpha)})
    end
    if #gradient == 3 then return { {0,0xff6666,0.3}, {0.5,0xff3333,0.3}, {1,0xff6666,0.3} } end
    return gradient
end

local border_color = parse_border_color(border_COLOR or "0,0x990000,1,0.5,0xff0000,1,1,0x990000,1")
local bg_color = parse_bg_color(bg_COLOR or "0x550000,0.8")
local layer2_color = parse_layer2_color(layer_2 or "0,0xff6666,0.3,0.5,0xff3333,0.3,1,0xff6666,0.3")

local function hex_to_rgba(hex, alpha)
    return ((hex>>16)&0xFF)/255, ((hex>>8)&0xFF)/255, (hex&0xFF)/255, alpha
end

local function draw_custom_rounded_rectangle(cr, x,y,w,h,r)
    local tl,tr,br,bl = unpack(r)
    cairo_new_path(cr)
    cairo_move_to(cr, x+tl, y)
    cairo_line_to(cr, x+w-tr, y)
    if tr>0 then cairo_arc(cr, x+w-tr, y+tr, tr, -math.pi/2,0) else cairo_line_to(cr, x+w,y) end
    cairo_line_to(cr, x+w, y+h-br)
    if br>0 then cairo_arc(cr, x+w-br, y+h-br, br,0,math.pi/2) else cairo_line_to(cr, x+w,y+h) end
    cairo_line_to(cr, x+bl, y+h)
    if bl>0 then cairo_arc(cr, x+bl, y+h-bl, bl, math.pi/2, math.pi) else cairo_line_to(cr,x,y+h) end
    cairo_line_to(cr, x, y+tl)
    if tl>0 then cairo_arc(cr, x+tl, y+tl, tl, math.pi, 3*math.pi/2) else cairo_line_to(cr,x,y) end
    cairo_close_path(cr)
end

local function get_centered_x(canvas_width, box_width)
    return (canvas_width-box_width)/2
end

-- Box definitions (dimensions set dynamically later)
local boxes_settings = {
    { type="background", draw_me=true, corners={0,0,0,0}, colour=bg_color },
    { type="layer2", draw_me=false, corners={20,20,20,20}, linear_gradient={103,0,103,206}, colours=layer2_color },
    { type="border", draw_me=true, border=1, corners={20,20,20,20}, colour=border_color, linear_gradient={0,0,0,170} }
}

-- Main draw function
function conky_draw_background()
    if not conky_window then return end
    local cs = cairo_xlib_surface_create(conky_window.display, conky_window.drawable,
                                         conky_window.visual, conky_window.width, conky_window.height)
    local cr = cairo_create(cs)
    local canvas_w, canvas_h = conky_window.width, conky_window.height

    cairo_save(cr)

    for _, box in ipairs(boxes_settings) do
        if box.draw_me then
            local x,y = 0,0
            local w,h = box.w or canvas_w, box.h or canvas_h
            local cx,cy = x+w/2, y+h/2
            local angle = (box.rotation or 0)*math.pi/180

            if box.type=="background" then
                cairo_save(cr)
                cairo_translate(cr, cx,cy)
                cairo_rotate(cr, angle)
                cairo_translate(cr, -cx,-cy)
                cairo_set_source_rgba(cr, hex_to_rgba(box.colour[1][2], box.colour[1][3]))
                draw_custom_rounded_rectangle(cr, x,y,w,h, box.corners)
                cairo_fill(cr)
                cairo_restore(cr)

            elseif box.type=="layer2" then
                local grad = cairo_pattern_create_linear(unpack(box.linear_gradient))
                for _, color in ipairs(box.colours) do
                    cairo_pattern_add_color_stop_rgba(grad, color[1], hex_to_rgba(color[2], color[3]))
                end
                cairo_set_source(cr, grad)
                draw_custom_rounded_rectangle(cr, x,y,w,h, box.corners)
                cairo_fill(cr)
                cairo_pattern_destroy(grad)

            elseif box.type=="border" then
                local grad = cairo_pattern_create_linear(unpack(box.linear_gradient))
                for _, color in ipairs(box.colour) do
                    cairo_pattern_add_color_stop_rgba(grad, color[1], hex_to_rgba(color[2], color[3]))
                end
                cairo_set_source(cr, grad)
                cairo_set_line_width(cr, box.border)
                draw_custom_rounded_rectangle(cr, x+box.border/2, y+box.border/2, w-box.border, h-box.border,
                                              {math.max(0,box.corners[1]-box.border/2),
                                               math.max(0,box.corners[2]-box.border/2),
                                               math.max(0,box.corners[3]-box.border/2),
                                               math.max(0,box.corners[4]-box.border/2)})
                cairo_stroke(cr)
                cairo_pattern_destroy(grad)
            end
        end
    end

    cairo_restore(cr)
    cairo_destroy(cr)
    cairo_surface_destroy(cs)
end


