-- loadall.lua
-- by @wim66
-- v4.1 May 2, 2025

-- Set the path to the scripts folder
package.path = "./scripts/?.lua"

-- Import modules
local success, background_red = pcall(require, 'background')
if not success then print("Error loading background module: "..background) end

-- Main function to draw Conky elements
function conky_main()
    if background then conky_draw_background() end
    if image then conky_fDrawImage(path,x,y,w,h,arc) end
end
