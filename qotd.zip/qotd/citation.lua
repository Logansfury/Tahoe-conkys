function conky_citation()
    local home = os.getenv("HOME")
    local path = home .. "/.conky/Tahoe/qotd/citation_en"
    local file = io.open(path, "r")

    if not file then
        return "${alignc}File not found"
    end

    local text = file:read("*all")
    file:close()

    local width = 26
    local output = ""

    for line in text:gmatch("[^\r\n]+") do
        while #line > width do
            local wrap_pos = width

            -- find nearest space before width
            for i = width, 1, -1 do
                if line:sub(i,i) == " " then
                    wrap_pos = i
                    break
                end
            end

            local part = line:sub(1, wrap_pos)
            output = output .. "${alignc}" .. part .. "\n"

            line = line:sub(wrap_pos + 1)
        end

        output = output .. "${alignc}" .. line .. "\n"
    end

    return output
end

