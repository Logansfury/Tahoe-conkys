#!/bin/bash

OUTFILE="/home/logansfury/.conky/Tahoe/qotd/citation_en"

# Fetch page once
PAGE=$(curl -s "https://www.calendarlabs.com/today/")

# Extract the quote: <p> immediately after "Thought of the Day"
QUOTE=$(echo "$PAGE" |
    awk '/Thought of the Day/{flag=1; next} /<p>/{if(flag){gsub(/^[ \t]+/,""); gsub(/<[^>]*>/,""); print; exit}}')

# Extract the author: first <strong> tag after the quote
AUTHOR=$(echo "$PAGE" |
    awk '/Thought of the Day/{flag=1} flag && /<strong>/{gsub(/^[ \t]+/,""); gsub(/<[^>]*>/,""); print; exit}')

# Format author so that any credentials (parentheses) appear on a new line
# E.g., "Robert Frost( 1874 - 1903 )" → "Robert Frost\n( 1874 - 1903 )"
AUTHOR_FORMATTED=$(echo "$AUTHOR" | sed 's/(\(.*\))/\n(\1)/')

# Output quote, blank line, then author
{
  echo "$QUOTE"
  echo " "
  echo -e "$AUTHOR_FORMATTED"
} > "$OUTFILE"

exit

