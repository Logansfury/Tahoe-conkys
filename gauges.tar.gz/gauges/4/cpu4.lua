require 'cairo'

-- Gauge data configuration
gauge = {
    {
        name='cpu',               -- Changed to CPU usage
        arg='cpu4',               -- Monitors CP1
        max_value=100,            -- Set max to 100% for CPU usage
        max_rpm=100,
        x=45,                    y=55,
        graph_radius=20,
        graph_thickness=7,
        graph_start_angle=225,
        graph_unit_angle=2.84,    
        graph_unit_thickness=2.7,
        graph_bg_colour=0xFFEEEE,    graph_bg_alpha=0.1,
        graph_fg_colour=0xFFFFFF,    graph_fg_alpha=1.0,
        hand_fg_colour=0xFFFFFF,     hand_fg_alpha=1.0,
        txt_radius=0,
        txt_weight=1,
        txt_font="Copperplate Gothic Light",
        txt_font_size=12,            
        txt_fg_colour=0xFFFFFF,      txt_fg_alpha=1.0,
        txt_x_offset=-10,            txt_y_offset=66,
        graduation_radius=26,
        graduation_thickness=7,       graduation_mark_thickness=1,
        graduation_unit_angle=13.5,
        graduation_fg_colour=0x8dddff, graduation_fg_alpha=1.0,
        caption='CPU4',
        caption_weight=1,
        caption_font="Copperplate Gothic Light",
        caption_font_size=12,
        caption_fg_colour=0x6495ee,  caption_fg_alpha=1.0,
        caption_x_offset=-16,        caption_y_offset=40,

        -- Needle Parameters
        needle_colour=0x6495ee,      
        needle_alpha=1.0,            
        needle_thickness=2,          
        needle_length=31,            
    },
}

-- Function to convert color to RGB
function rgb_to_r_g_b(colour, alpha)
    return ((colour / 0x10000) % 0x100) / 255., ((colour / 0x100) % 0x100) / 255., (colour % 0x100) / 255., alpha
end

-- Function to convert angle to position
function angle_to_position(start_angle, current_angle)
    local pos = current_angle + start_angle
    return ((pos * (2 * math.pi / 360)) - (math.pi / 2))
end

-- Function to draw gauge ring
function draw_gauge_ring(display, data, value)
    local max_value = data['max_value']
    local x, y = data['x'], data['y']
    local graph_radius = data['graph_radius']
    local graph_thickness, graph_unit_thickness = data['graph_thickness'], data['graph_unit_thickness']
    local graph_start_angle = data['graph_start_angle']
    local graph_unit_angle = data['graph_unit_angle']
    local graph_bg_colour, graph_bg_alpha = data['graph_bg_colour'], data['graph_bg_alpha']
    local graph_fg_colour, graph_fg_alpha = data['graph_fg_colour'], data['graph_fg_alpha']
    local graph_end_angle = (max_value * graph_unit_angle) % 360

    -- Background ring
    cairo_arc(display, x, y, graph_radius, angle_to_position(graph_start_angle, 0), angle_to_position(graph_start_angle, graph_end_angle))
    cairo_set_source_rgba(display, rgb_to_r_g_b(graph_bg_colour, graph_bg_alpha))
    cairo_set_line_width(display, graph_thickness)
    cairo_stroke(display)

    -- Arc of value
    local val = value % (max_value + 1)

    -- Subtract 3% for the foreground arc only
    local adjusted_val = val > 1 and (val - 3) or val

    local start_arc = 0
    local stop_arc = 0
    local i = 1
    while i <= adjusted_val do
    start_arc = (graph_unit_angle * i) - graph_unit_thickness
    stop_arc = (graph_unit_angle * i)
    cairo_arc(display, x, y, graph_radius, angle_to_position(graph_start_angle, start_arc), angle_to_position(graph_start_angle, stop_arc))
    cairo_set_source_rgba(display, rgb_to_r_g_b(graph_fg_colour, graph_fg_alpha))
    cairo_stroke(display)
    i = i + 1
end


    -- Needle
    local angle = angle_to_position(graph_start_angle, graph_unit_angle * val) - 0.15
    local needle_length = data['needle_length']
    cairo_move_to(display, x, y)
    cairo_line_to(display, x + needle_length * math.cos(angle), y + needle_length * math.sin(angle))
    cairo_set_source_rgba(display, rgb_to_r_g_b(data['needle_colour'], data['needle_alpha']))
    cairo_set_line_width(display, data['needle_thickness'])
    cairo_stroke(display)
end


-- Function to draw numbers around the circle and change color
function draw_numbers(display, x_center, y_center, radius, start_angle, step_angle, numbers, value)
    cairo_select_font_face(display, "Sans", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL)
    cairo_set_font_size(display, 9)

    for i, num in ipairs(numbers) do
        local angle = start_angle + (i - 1) * step_angle
        local x = x_center + (radius + 5) * math.cos(angle)
        local y = y_center + (radius + 5) * math.sin(angle)

        -- Change color to blue if value exceeds corresponding number
        if value >= num then
            cairo_set_source_rgba(display, 0.55, 0.87, 1, 1)  -- Blue color (141, 221, 255)
        else
            cairo_set_source_rgba(display, 1, 1, 1, 1)  -- White color (255, 255, 255)
        end

        cairo_move_to(display, x - 7, y + 5)
        cairo_show_text(display, tostring(num))
    end
end

-- Function to draw RPM text and caption
function draw_rpm_text_and_caption(display, data, value)
    local rpm_value = conky_parse(string.format('${%s %s}', data['name'], data['arg']))

    -- RPM Text
    cairo_select_font_face(display, data['txt_font'], CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL)
    cairo_set_font_size(display, data['txt_font_size'])
    cairo_set_source_rgba(display, rgb_to_r_g_b(data['txt_fg_colour'], data['txt_fg_alpha']))
    cairo_move_to(display, data['x'] + data['txt_x_offset'], data['y'] + data['txt_y_offset'])
    cairo_show_text(display, rpm_value .. "%")

    -- Caption Text
    cairo_select_font_face(display, data['caption_font'], CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL)
    cairo_set_font_size(display, data['caption_font_size'])
    cairo_set_source_rgba(display, rgb_to_r_g_b(data['caption_fg_colour'], data['caption_fg_alpha']))
    cairo_move_to(display, data['x'] + data['caption_x_offset'], data['y'] + data['caption_y_offset'])
    cairo_show_text(display, data['caption'])
end

-- Main function to draw gauge and numbers
function go_gauge_rings(display)
    local function load_gauge_rings(display, data)
        local value = tonumber(conky_parse(string.format('${%s %s}', data['name'], data['arg'])))
        draw_gauge_ring(display, data, value)
        draw_rpm_text_and_caption(display, data, value)
        draw_numbers(display, data['x'], data['y'], 26, math.rad(144), math.rad(28), {10, 20, 30, 40, 50, 60, 70, 80, 90, 100}, value)
    end

    for i, data in ipairs(gauge) do
        load_gauge_rings(display, data)
    end
end

function conky_main()
    if conky_window == nil then return end
    local cs = cairo_xlib_surface_create(conky_window.display, conky_window.drawable, conky_window.visual, conky_window.width, conky_window.height)
    local display = cairo_create(cs)

    go_gauge_rings(display)

    cairo_surface_destroy(cs)
    cairo_destroy(display)
end
